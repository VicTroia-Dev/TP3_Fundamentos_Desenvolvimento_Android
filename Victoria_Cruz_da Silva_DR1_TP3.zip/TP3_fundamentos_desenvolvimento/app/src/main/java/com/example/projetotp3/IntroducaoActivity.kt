package com.example.projetotp3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.Toast
import com.example.projetotp3.databinding.ActivityIntroducaoBinding



class IntroducaoActivity : AppCompatActivity(R.layout.activity_introducao) {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val botao_iniciar = findViewById<Button>(R.id.button2)

        botao_iniciar.setOnClickListener{
            val intent = Intent(this, form::class.java)
            startActivity(intent)
        }
    }
}