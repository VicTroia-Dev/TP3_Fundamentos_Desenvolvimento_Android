package com.example.projetotp3

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import com.example.projetotp3.model.opcoes

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class pagina2 : Fragment() {

    var op = opcoes()
    var testes = com.example.projetotp3.model.testes()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.pergunta2, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        var resp = -1
        val button = view.findViewById<Button>(R.id.btn_prgnt2)
        var list_agr : MutableList<Int> = mutableListOf(0)
        var agr = 0

        button.isEnabled = false

        val botao1 = view.findViewById<Button>(R.id.resposta_2a)
        val botao2 = view.findViewById<Button>(R.id.resposta_2b)
        val botao3 = view.findViewById<Button>(R.id.resposta_2c)
        val botao4 = view.findViewById<Button>(R.id.resposta_2d)

        botao1?.setOnClickListener {
            resp = 1
            agr = 0
            list_agr.add(agr)
            verificabtn(resp,button)
        }
        botao2?.setOnClickListener {
            resp =1
            agr = 2
            list_agr.add(agr)
            verificabtn(resp,button)
        }
        botao3?.setOnClickListener {
            resp = 1
            agr = 4
            list_agr.add(agr)
            verificabtn(resp,button)

        }
        botao4?.setOnClickListener {
            resp = 1
            agr = 5
            list_agr.add(agr)
            verificabtn(resp,button)
        }


        button?.setOnClickListener {

            val agrRec = requireArguments().getInt("agr1")

            val ultimo = (list_agr.last() + agrRec )
            println(ultimo)

            findNavController().navigate(R.id.action_pagina2_to_pagina3, Bundle().apply {
                putInt("agr2",ultimo)
            })



        }

    }

    fun verificabtn(valor:Int,btn:Button){
        if(valor > 0){
            btn.isEnabled = true
        }else{
            btn.isEnabled = false
        }
    }

}