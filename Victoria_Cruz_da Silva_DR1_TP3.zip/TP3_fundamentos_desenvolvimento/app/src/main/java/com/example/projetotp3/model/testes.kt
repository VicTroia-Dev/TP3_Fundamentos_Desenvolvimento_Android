package com.example.projetotp3.model

class testes {
    var lista_resp: MutableList<Any> = mutableListOf()


    fun listar(item:Int){
        lista_resp.add(item)
    }


}